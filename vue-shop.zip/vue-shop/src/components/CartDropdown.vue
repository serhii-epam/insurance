<template>
<!--
  <div class="dropdown-clip" v-if="cart.length > 0">
    <transition name="dropdown">
      <div
        v-if="displayCart"
        class="list-group"
        aria-labelledby="cartDropdown"
      >
        <div v-for="(item, index) in cart" :key="index">
          <div 
            class="dropdown-item-text text-nowrap text-right align-middle bg-white" 
            style='border-top: 1px solid lightgray'>
            <div class="badge bg-success mr-1">
              {{ item.qty }}</div>
            {{ item.product.name }}
            <b>
              <curr :amt="item.qty * Number(item.product.price)"></curr>
            </b>
            <button
              @click.stop="this.$parent.$emit('deleteItem', index)"
              class="btn btn-sm btn-danger ml-1"
            >
              -
            </button>            
          </div>
        </div>
        <router-link
          to="/checkout"
          class="btn btn-sm btn-success text-white float-right mr-2 mt-1"
        >
          checkout
        </router-link>
      </div>
    </transition>
  </div>    
 -->
 <div>
    <div class="dropdown-clip" style="box-shadow: 10px 5px 5px black;" v-if="cart.length > 0">
      <transition name="dropdown">
        <div v-if="displayCart" class="list-group" aria-labelledby="cartDropdown">
          <div style = "background-color:powderblue;"
            v-for="(item, index) in cart"
            :key="index"
            class="list-group-item d-flex justify-content-between"
          >
            <div class="badge bg-success mr-1">
              {{ item.qty }}</div>
            {{ item.product.name }}, 
            <b>
              <curr :amt="item.qty * Number(item.product.price)"></curr>
            </b>

            <button
              @click.stop="this.$parent.$emit('deleteItem', index)"
              class="btn btn-sm btn-danger ml-1"
            >
              -
            </button>            
          </div>
          <router-link
          to="/checkout"
          class="btn btn-sm btn-primary text-white float-right mr-2 mt-1"
        >
          Checkout
        </router-link>

        </div>
      </transition>
    </div>
  </div>
</template>

<script>
import Curr from '@/components/Currency'

export default {
  props: ['cart', 'displayCart'],
  emits: ['deleteItem'],
  components: {
    Curr
  }
}
</script>

<style>

.list-group{
    max-height: 600px;
    margin-bottom: 10px;
    overflow-y: scroll;
    -webkit-overflow-scrolling: touch;
}

.dropdown-clip {
    overflow: hidden;
}
  
.dropdown-enter-active,
.dropdown-leave-active {
    transition: all 0.2s ease-in-out;
    transform: auto;
}
  
.dropdown-enter-from,
.dropdown-leave-to {
    opacity: 0;
    transform: translateY(-300px);
}
</style>