<template>
  <div>
    <h2>Product Id: {{ $route.params.id }}</h2>
    <div v-for="item in prods" :key="item.id">
    <div class="row">
      <div class="col-sm-4">
        <img class="img-fluid d-block" :src="item.image" :alt="item.name" />
      </div>
      <div class="col">
        <h3 class="text-primary">{{ item.name }}</h3>
        <p class="mb-0">{{ item.description }}</p>
        <div class="h5 float-right">
          <span class="label"></span><curr :amt="item.price"></curr>
        </div>
        <button 
          class="btn btn-sm btn-success" 
          style="margin-top: 10px" 
          @click="$router.go(-1)"
          >Go Back
        </button>
      </div> 
    </div>
  </div>
  </div>

</template>

<script>
import Curr from '@/components/Currency'
export default {
    data() {
        return {
            prods: []
        }
    },
    props: ['products'],
    components: {
    Curr    
    },
    created() {
      if (this.products && this.products.length > 0) {
        for (var j = 0; j < this.products.length; j++) {
          if (this.products[j].id == this.$route.params.id) {
              this.prods.push(this.products[j])
              break
          }
        }        
      } else {
        let id = this.$route.params.id
        fetch(`https://hplussport.com/api/products/order/price?id=${id}`)
          .then(response => response.json())
          .then(data => {
            this.prods = data
            console.log(this.prods)
        })
      }
    }
}
</script>

<style>

</style>