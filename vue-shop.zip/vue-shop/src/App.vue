<template>
  <navbar-cart 
    :displayCart="displayCart"
    :cart="cart" 
    :cart-total="cartTotal" 
    :cart-qty="cartQty" 
    @deleteItem="deleteItem"
    @toggleCartMenu="toggleCartMenu"
  />
  <div class="container">
    <router-view 
      :products="products" 
      :cart="cart" 
      :cart-total="cartTotal" 
      @addItem="addItem" 
      @deleteItem="deleteItem"
      @toggleCartMenu="toggleCartMenu"
      @hideCartMenu="hideCartMenu"
    />
  </div>
</template>

<script>
import NavbarCart from '@/components/NavbarCart.vue';
export default {
  data: function() {
    return {
      maxPrice: 70,
      displayCart: false,
      cart: [],
      products: []
    }
  },
  components: {
    NavbarCart
  },
  computed: {
    cartTotal() {
      let sum = 0
      for (let ind in this.cart) {
        sum = sum + this.cart[ind].product.price * this.cart[ind].qty
      }
      return sum
    },
    cartQty: function() {
      let qty = 0
      for (let ind in this.cart) {
        qty = qty + this.cart[ind].qty
      }
      return qty
    }
  },
  methods: {
    addItem(product) {
      let whichProduct = 0
      let existing = this.cart.filter((item, index) => {
        if (item.product.id == Number(product.id)) {
          whichProduct = index
          return true
        }
        else {
          return false
        }
      })
      if (existing.length) {
        this.cart[whichProduct].qty ++
      }
      else {
        this.cart.push({ product: product, qty: 1})
      }
    },
    deleteItem(ind) {
      if (this.cart[ind].qty > 1) {
        this.cart[ind].qty--
      } else {
        this.cart.splice(ind, 1)
      }
      if (this.cart.length==0) {
        this.toggleCartMenu()    
      }
    },
    toggleCartMenu() {
      //console.log('blaaaa')
      this.displayCart = !this.displayCart
    },
    hideCartMenu() {
      //console.log('blaaaa')
      this.displayCart = false
    }
  },
  created() {
    fetch('https://hplussport.com/api/products/order/price')
      .then(response => response.json())
      .then(data => {
        this.products = data
        console.log(this.products)
      })
      
  }
}
</script>

<style lang="scss">
  $primary: #6f42c1;
  @import 'node_modules/bootstrap/scss/bootstrap';

  .lnk {
    cursor: pointer
  }

</style>
